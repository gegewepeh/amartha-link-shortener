package models

type Link struct {
	ID        string `json:"id,omitempty"`
	FullLink  string `json:"fullLink,omitempty"`
	Slug      string `json:"slug,omitempty"`
	Visit     int    `json:"visit,omitempty"`
	CreatedAt string `json:"createdAt,omitempty"`
	UpdatedAt int    `json:"updatedAt,omitempty"`
}

type CreateSlugRequest struct {
	FullLink string `json:"fullLink"`
}
