package handler

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"

	v1 "link-shortener/internal/app/link_shortener/main/services/v1"
	models "link-shortener/internal/app/link_shortener/models"
	network "link-shortener/internal/pkg/network"
	utils "link-shortener/internal/pkg/utils"

	"github.com/gorilla/mux"
	"github.com/gorilla/websocket"
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin:     func(r *http.Request) bool { return true },
}

func getAllLinks(w http.ResponseWriter, r *http.Request) (*network.Response, *utils.AppError) {
	ctx := createContext(r)
	vars := mux.Vars(r)
	id := vars["id"]
	page := r.URL.Query().Get("page")
	perPage := r.URL.Query().Get("perPage")

	pool := v1.GetPool()
	data, _ := pool.GetLinks(ctx, id, page, perPage)

	resp := &network.Response{
		Code: 200,
		Data: data,
		Meta: nil,
	}

	return resp, nil
}

func getBySlugId(w http.ResponseWriter, r *http.Request) (*network.Response, *utils.AppError) {
	ctx := createContext(r)
	vars := mux.Vars(r)
	id := vars["id"]

	pool := v1.GetPool()
	data, err := pool.GetBySlugId(ctx, id)
	if err != nil {
		return nil, err
	}

	return &network.Response{
		Code: 301,
		Data: data,
		Meta: nil,
	}, nil
}

func createSlug(w http.ResponseWriter, r *http.Request) (*network.Response, *utils.AppError) {
	var request models.CreateSlugRequest
	ctx := createContext(r)

	decodeErr := json.NewDecoder(r.Body).Decode(&request)
	if decodeErr != nil {
		return nil, models.WrapError("General", "JSONError", decodeErr, nil)
	}
	utils.PrettyLog(ctx, utils.IsValidURL(request.FullLink))

	if utils.IsValidURL(request.FullLink) == false {
		return nil, models.WrapError("Link", "InvalidParameters", errors.New("Invalid URL Format"), nil)
	}

	generatedSlugId := utils.RandString(6, false)
	pool := v1.GetPool()
	data, err := pool.CreateSlug(ctx, request.FullLink, generatedSlugId)
	if err != nil {
		return nil, err
	}

	return &network.Response{
		Code: 201,
		Data: data,
		Meta: nil,
	}, nil
}

func createContext(r *http.Request) context.Context {
	ctx := r.Context()
	reqID := r.Header.Get("X-Request-Id")
	if reqID == "" {
		reqID = utils.RandString(8, true)
	}
	ctx = utils.SetRequestID(ctx, reqID)
	return ctx
}
