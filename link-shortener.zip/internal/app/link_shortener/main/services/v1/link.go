package v1

import (
	"context"
	"errors"
	"fmt"
	"link-shortener/internal/app/link_shortener/models"
	"link-shortener/internal/pkg/utils"
	"log"
	"os"
	"time"

	"github.com/google/uuid"
)

func (pool *Pool) GetLinks(ctx context.Context, id string, page string, perPage string) (string, error) {
	rows, err := pool.db.Query(ctx, "SELECT * FROM links")
	if err != nil {
		fmt.Fprintf(os.Stderr, "QueryRow failed: %v\n", err)
	}

	for rows.Next() {
		values, err := rows.Values()
		if err != nil {
			log.Fatal("error while iterating dataset")
		}

		// convert DB types to Go types
		id := values[0].([16]uint8)
		fullLink := values[1].(string)
		slug := values[2].(string)
		visit := values[3].(int32)
		createdAt := values[4].(time.Time)
		updatedAt := values[5].(time.Time)

		uuidFromBytes, _ := uuid.FromBytes(id[:])
		idString := uuidFromBytes.String()

		log.Println("[id:", idString, ", fullLink:", fullLink, ", slug:", slug, ", visit:", visit, ", createdAt:", createdAt, ", updatedAt:", updatedAt, "]")
	}

	return "test", nil
}

func (pool *Pool) GetBySlugId(ctx context.Context, id string) (*models.Link, *utils.AppError) {
	var fullLink string
	var visit int

	queryUpdate := `UPDATE links
	SET visit = visit + 1
	WHERE slug = $1
	RETURNING "fullLink", "visit"`

	utils.Log(ctx, "GetBySlugId QUERY: %s", queryUpdate)
	err := pool.db.QueryRow(ctx, queryUpdate, id).Scan(&fullLink, &visit)
	if err != nil {
		return nil, models.WrapError("Link", "NotFound", errors.New("Link Not Found"), nil)
	}

	link := models.Link{
		FullLink: fullLink,
		Visit:    visit,
	}

	return &link, nil
}

func (pool *Pool) CreateSlug(ctx context.Context, fullLink string, slug string) (*models.Link, *utils.AppError) {
	query := `INSERT INTO links("fullLink", slug, visit, "createdAt", "updatedAt")
	VALUES ($1, $2, 0, NOW(), NOW())
	RETURNING slug`

	err := pool.db.QueryRow(ctx, query, fullLink, slug).Scan(&slug)
	if err != nil {
		return nil, models.WrapError("Link", "InternalServerError", err, nil)
	}
	link := models.Link{
		Slug: "www.example.com/" + slug,
	}

	return &link, nil
}
