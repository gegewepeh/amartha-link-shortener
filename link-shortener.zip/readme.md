# SETUP DB
CREATE TABLE links (
	id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
	"fullLink" VARCHAR ( 100 ) NOT NULL,
	slug VARCHAR ( 6 ) UNIQUE NOT NULL,
	visit INT4 NOT NULL,
	"createdAt" TIMESTAMPTZ NOT NULL,
    "updatedAt" TIMESTAMPTZ NOT NULL
);


## Run Project

- run `go mod tidy`
- run `go mod download`
- copy .env.sample to .env (adjust for local user and password)
- run `export ENV=development`
- run `go run ./cmd/link_shortener.go`


## Available Endpoint

#### Show ALL Links in logs
GET {{host}}/link-shortener/v1/links

#### Show full link with slug (will count as 1 visit)
GET {{host}}/link-shortener/v1/slug/:id

#### Create Slug
POST {{host}}/link-shortener/v1/slug

Body JSON example:
```
{
    "fullLink": "www.google.com"
}
```